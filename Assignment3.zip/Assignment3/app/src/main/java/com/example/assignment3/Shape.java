package com.example.assignment3;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.Random;

import static java.lang.Math.abs;

public abstract class Shape {
    protected static float RADIUS = 50;
    protected float _x;
    protected float _y;
    protected int _radius;
    protected int _color;
    protected Paint _paint = new Paint();
    protected float xVel, yVel;

    public int OBJ_RADIUS = 30;
    public int METRICS_WIDTH= Resources.getSystem().getDisplayMetrics().widthPixels;
    public int METRICS_HEIGHT=Resources.getSystem().getDisplayMetrics().heightPixels;

    public Shape(float x, float y, int radius, int color){
        _x = x;
        _y = y;
        _radius = radius;
        _color = color;
        _paint.setColor(_color);
    }

    public float GetX(){
        return _x;
    }
    public void SetX(float x){
        this._x = x;
    }

    public float GetY(){
        return _y;
    }
    public void SetY(float y){
        this._y = y;
    }

    public abstract void Draw(Canvas canvas);

    public boolean Contact(Shape s) {
        if(s.GetX() > this.GetX() - (s._radius + this._radius) && s.GetX() < this.GetX() + s._radius + this._radius){
            if(s.GetY() > this.GetY() - (s._radius + this._radius) && s.GetY() < this.GetY() + s._radius + this._radius) {
                return true;
            }
        }
        return false;
    }


        public void MoveTo () {
            Random rand = new Random();
            this.SetX(this.GetX() + xVel);
            this.SetY(this.GetY() + yVel);

            if (this.GetX() + OBJ_RADIUS > METRICS_WIDTH) {
                xVel = -xVel;
                this.SetX(METRICS_WIDTH - OBJ_RADIUS);
            } else if (this.GetX() - OBJ_RADIUS < 0) {
                xVel = -xVel;
                this.SetX(OBJ_RADIUS);
            }
            if (this.GetY() + OBJ_RADIUS > METRICS_HEIGHT) {
                yVel = -yVel ;
                this.SetY(METRICS_HEIGHT - OBJ_RADIUS);
            } else if (this.GetY() - OBJ_RADIUS < 0) {
                yVel = -yVel;
                this.SetY(OBJ_RADIUS);
            }

        }



}
