package com.example.assignment3;

//Singleton class to get the instances
public class Singleton {

    private static Singleton instance;
    private static int scores;

    //method to get an instance
    public static Singleton getInstance(){
        if(instance == null){
            instance = new Singleton();
        }
        return instance;
    }

    public int getScores(){
        return scores;
    }

    public static void SetScore(int _scores){
        scores = _scores;
    }

}
