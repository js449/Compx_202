package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import static java.lang.String.valueOf;

public class ActivityHighScores extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_scores);

        Button back_button = findViewById(R.id.back_button);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ActivityGameScreen.class);
                startActivity(intent);
            }
        });

        ArrayList<Integer> SingleArray = new ArrayList<Integer>();
        Singleton singleScores1 = Singleton.getInstance();
        SingleArray.add(singleScores1.getScores());
        TextView display1 = (TextView)findViewById(R.id.display_score1);
        TextView display2 = (TextView)findViewById(R.id.display_score2);
        TextView display3 = (TextView)findViewById(R.id.display_score3);
        TextView display4 = (TextView)findViewById(R.id.display_score4);
        TextView display5 = (TextView)findViewById(R.id.display_score5);

        for(int i =0;i<SingleArray.size();i++){
            if(SingleArray.get(i) < singleScores1.getScores()){
                SingleArray.set(i, singleScores1.getScores());
                }
            if (SingleArray.get(i) == 1){
                display2.setText("Score: " + String.valueOf(SingleArray.get(i)));
            }
            else if(SingleArray.get(i) ==2){
                display3.setText("Score: " + String.valueOf(SingleArray.get(i)));
            }
            else if(SingleArray.get(i) == 3){
                display4.setText("Score: " + String.valueOf(SingleArray.get(i)));
            }
            else if(SingleArray.get(i) == 4){
                display5.setText("Score: " + String.valueOf(SingleArray.get(i)));
            }
            else{
                display1.setText("Score: " + String.valueOf(SingleArray.get(i)));
            }

        }








    }
}