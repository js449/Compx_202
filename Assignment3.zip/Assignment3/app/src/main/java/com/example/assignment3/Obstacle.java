package com.example.assignment3;

import android.graphics.Canvas;

import static java.lang.Math.abs;

public class Obstacle extends Shape {


    public Obstacle(float x, float y, int radius, int color) {
        super(x, y, radius, color);
        xVel = 1;
        yVel = 1;
    }

    @Override
    public void Draw(Canvas canvas) {
        canvas.drawCircle(_x,_y,_radius, _paint);

    }

    public float getXVel() { return xVel; }
    public void setXVel(float _xVel){
        xVel = _xVel;
    }

    public float getYVel() { return yVel; }
    public void setYVel(float _yVel){ yVel = _yVel; }



}
