package com.example.assignment3;


import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Player extends Shape {

    //constructor
    public Player(float x, float y, int radius, int color) {
        super(x, y, radius, color);
    }

    @Override
    public void Draw(Canvas canvas) {
        canvas.drawCircle(_x, _y, _radius, _paint);
    }

    public boolean TouchWalls(Player p) {
        if (super.GetY() > METRICS_HEIGHT) {
            super.SetY(METRICS_HEIGHT);
            return true;
        } else if (super.GetY() < 0) {
            super.SetY(0);
            return true;
        } else if (super.GetX() > METRICS_WIDTH) {
            super.SetX(METRICS_WIDTH );
            return true;
        } else if (super.GetX() < 0) {
            super.SetX(0);
            return true;
        } else {
            return false;
        }
    }
}



