package com.example.assignment3;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.Random;

import static java.lang.Math.abs;

/**
 * Creates a shape object for other class to inherit from
 *
 */
public abstract class Shape {
    protected static float RADIUS = 50;
    protected float _x;
    protected float _y;
    protected int _radius;
    protected int _color;
    protected Paint _paint = new Paint();
    protected float xVel, yVel;

    //Sets the obstacle radius
    public int OBJ_RADIUS = 30;
    //Get the width and height of the phone
    public int METRICS_WIDTH= Resources.getSystem().getDisplayMetrics().widthPixels;
    public int METRICS_HEIGHT=Resources.getSystem().getDisplayMetrics().heightPixels;

    /**
     *
     * @param x x position of the shape on the screen
     * @param y y position of the shape on the creen
     * @param radius the radius of the shape
     * @param color sets the color of the shape
     */
    public Shape(float x, float y, int radius, int color){
        _x = x;
        _y = y;
        _radius = radius;
        _color = color;
        _paint.setColor(_color);
    }

    /**
     * Gets the x position of the shape
     * @return
     */
    public float GetX(){
        return _x;
    }

    /**
     * Sets the x position of the shape
     * @param x
     */
    public void SetX(float x){
        this._x = x;
    }

    /**
     * Gets the y position of the shape
     * @return
     */
    public float GetY(){
        return _y;
    }

    /**
     * Sets the y position of the shape
     * @param y
     */
    public void SetY(float y){
        this._y = y;
    }

    /**
     * Draws the shape on the phone using canvas
     * @param canvas
     */
    public abstract void Draw(Canvas canvas);

    /**
     * Checks if the shape has made contact with another shape
     * @param s passes in the a shape
     * @return true if contact has been made, otherwise false
     */
    public boolean Contact(Shape s) {
        if(s.GetX() > this.GetX() - (s._radius + this._radius) && s.GetX() < this.GetX() + s._radius + this._radius){
            if(s.GetY() > this.GetY() - (s._radius + this._radius) && s.GetY() < this.GetY() + s._radius + this._radius) {
                return true;
            }
        }
        return false;
    }

    /**
     * Moves the shape around the screen
     * and changes the velocity of the shape if it has
     * made contact with the side of the phone
     */
    public void MoveTo () {
            Random rand = new Random();
            this.SetX(this.GetX() + xVel);
            this.SetY(this.GetY() + yVel);

            if (this.GetX() + OBJ_RADIUS > METRICS_WIDTH) {
                xVel = -xVel;
                this.SetX(METRICS_WIDTH - OBJ_RADIUS);
            } else if (this.GetX() - OBJ_RADIUS < 0) {
                xVel = -xVel;
                this.SetX(OBJ_RADIUS);
            }
            if (this.GetY() + OBJ_RADIUS > METRICS_HEIGHT) {
                yVel = -yVel ;
                this.SetY(METRICS_HEIGHT - OBJ_RADIUS);
            } else if (this.GetY() - OBJ_RADIUS < 0) {
                yVel = -yVel;
                this.SetY(OBJ_RADIUS);
            }

        }



}
