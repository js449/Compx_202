package com.example.assignment3;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

public class Target extends Shape {

    public Target(float x, float y, int radius, int color) {
        super(x, y, radius, color);
    }

    @Override
    public void Draw(Canvas canvas) {
        canvas.drawCircle(_x, _y,_radius, _paint);
    }


}
