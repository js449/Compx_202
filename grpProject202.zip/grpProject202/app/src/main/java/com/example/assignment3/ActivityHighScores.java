package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import static java.lang.String.valueOf;

public class ActivityHighScores extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high_scores);

        Button back_button = findViewById(R.id.back_button);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(view.getContext(), ActivityGameScreen.class);
                startActivity(intent);
            }
        });

        Singleton singleScores = Singleton.getInstance();

        TextView display1 = (TextView)findViewById(R.id.display_score1);
        TextView display2 = (TextView)findViewById(R.id.display_score2);
        TextView display3 = (TextView)findViewById(R.id.display_score3);
        TextView display4 = (TextView)findViewById(R.id.display_score4);
        TextView display5 = (TextView)findViewById(R.id.display_score5);

        display1.setText("Score: " + (singleScores.getScores()[0]));
        display2.setText("Score: " + (singleScores.getScores()[1]));
        display3.setText("Score: " + (singleScores.getScores()[2]));
        display4.setText("Score: " + (singleScores.getScores()[3]));
        display5.setText("Score: " + (singleScores.getScores()[4]));

    }
}