package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 */
public class ActivityGameScreen extends AppCompatActivity {
    //class variables
    SensorManager sensorManager;
    Sensor accelerometerSensor;
    Paint paint;
    float r;
    int playerColor = 0xffff0000;
    int targetColor = 0xff00ff00;
    int obstacleColor = 0xff0000ff;
    int RADIUS = 25;

    public String TAG = "TESTING";

    //To get width and height of the screen
    public int WIDTH= Resources.getSystem().getDisplayMetrics().widthPixels;
    public int HEIGHT=Resources.getSystem().getDisplayMetrics().heightPixels;

    float xs = WIDTH / 2;
    float ys = HEIGHT / 2;

    Player p = new Player(WIDTH / 2,HEIGHT / 2, 50, playerColor);
    Target t = new Target(0,500, RADIUS, targetColor);

    //Array list for the ball and obstacles
    List<Shape> shapesList = new ArrayList<Shape>();
    List<Obstacle> objList = new ArrayList<Obstacle>();

    Obstacle o1 = new Obstacle(RandomX(), 150, 30, obstacleColor);
    Obstacle o2 = new Obstacle(RandomX(), HEIGHT - 100, 30, obstacleColor);
    Obstacle o3 = new Obstacle(RandomX(), HEIGHT - 100, 30, obstacleColor);

    SensorEventListener accelerometerListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            float tmpx = event.values[0];
            float tmpy = event.values[1];
            //Invert the controls
            tmpx *= -1;
            xs += tmpx;
            ys += tmpy;

            //If the player is on the wall then set the velocity to 0
            if (xs > WIDTH) {
                xs = WIDTH;
            }
            if (xs < 0) {
                xs = 0;
            }
            if (ys > HEIGHT) {
                ys = HEIGHT;
            }
            if (ys < 0) {
                ys = 0;
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);

        Intent intent = getIntent();

        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accelerometerSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        GraphicsView graphicsView = new GraphicsView(this);
        ConstraintLayout constraintLayoutMain = (ConstraintLayout)findViewById(R.id.cl_play_screen);
        constraintLayoutMain.addView(graphicsView);

        //Enable Sticky Immersive Mode For the Full Screen
        int ui_Visibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        getWindow().getDecorView().setSystemUiVisibility(ui_Visibility);

        shapesList.add(p);
        shapesList.add(t);
        objList.add(o1);
        objList.add(o2);
        objList.add(o3);

    }

    public float RandomX(){
        return r = new Random().nextFloat() * (WIDTH - 50);
    }
    public float RandomY(){
        return r = new Random().nextFloat() * (HEIGHT - 50);
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(accelerometerListener, accelerometerSensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(accelerometerListener,accelerometerSensor);
    }

    //Graphic view class
    public class GraphicsView extends View {

        private Singleton singleScores;
        private Context context;
        private int score = 0;
        private int i = 0;

        //Constructor
        public GraphicsView(Context context) {
            super(context);
            this.context = context;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            for(Shape s : shapesList){
                if(s.equals(p)){
                    if(p.TouchWalls(p) == true){

                    }
                    else{
                        shapesList.set(0, p = new Player(xs, ys, 50, playerColor));
                    }
                }

                //Check if the player circle has made contact with the target circle
                //And move the target circle to a new location
                if(p.Contact(t)){
                    shapesList.set(1, t = new Target(RandomX(), RandomY(), RADIUS, targetColor));
                    score += 1;
                    Singleton.SetScore(score, i);
                    i += 1;
                    if(i == 5){
                        i = 0;
                    }
                }
                s.Draw(canvas);

                for(Obstacle o : objList){
                    //Lose game goto hi scores page here
                    if(p.Contact(o)){

                        Intent scoreIntent = new Intent(context, ActivityHighScores.class);
                        singleScores = Singleton.getInstance();
                        startActivity(scoreIntent);
                        return;
                    }

                    if(o.Contact(o1) && o != o1){
                        o1.setXVel(o1.getXVel() * -1);
                    }
                    if(o.Contact(o2) && o != o2){
                        o2.setXVel(o2.getXVel() * -1);
                    }
                    if(o.Contact(o3) && o != o3){
                        o3.setXVel(o3.getXVel() * -1);
                    }
                    o.Draw(canvas);
                    o.MoveTo();
                }
            }
            invalidate();
        }

    }
}