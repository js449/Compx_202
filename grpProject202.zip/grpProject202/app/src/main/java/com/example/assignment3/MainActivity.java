package com.example.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //method to pass the view for play button
    public void onClick(View view){
        //creating a new intent to pass the Activity game screen parameter that we want to open when click button.
        Intent intent = new Intent(view.getContext(), ActivityGameScreen.class);
        startActivity(intent);

    }

}