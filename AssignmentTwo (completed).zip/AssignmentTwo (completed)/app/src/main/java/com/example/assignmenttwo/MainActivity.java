package com.example.assignmenttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     *
     * @param view
     */
    public void onClickCs(View view){
        startDetailActivity(0);
    }

    /**
     *
     * @param view
     */
    public void onClickDesign(View view){
        startDetailActivity(1);
    }

    /**
     *
     * @param view
     */
    public void onClickMath(View view){
        startDetailActivity(2);
    }

    /**
     *
     * @param view
     */
    public void onClickSe(View view){
        startDetailActivity(3);
    }

    /**
     * startDetailActivity is a method that has been created to open a new activity
     * Called by onClickCS, onClickDesign, onClickMath, and onClickSe
     * @param position 0, 1, 2, or 3 depending on which button has been clicked
     *                 the position is associated with the index in the arrays
     */
    public void startDetailActivity(int position){
        Intent i = new Intent(this, DetailActivity.class);
        i.putExtra("pos", position);
        startActivity(i);
    }

}
