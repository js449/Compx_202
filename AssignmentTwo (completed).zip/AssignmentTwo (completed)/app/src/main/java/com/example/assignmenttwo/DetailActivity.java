package com.example.assignmenttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class DetailActivity extends AppCompatActivity {

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Get the position out of the intent
        // This position corresponds to the index of values in the arrays.xml file
        // 0 = cs, 1 = design, 2 = math, and 3 = se
        Intent i                 = getIntent();
        int position             = i.getIntExtra("pos", 0);

        // Get the textviews and imageview that will be updated
        TextView textViewTitle   = (TextView) findViewById(R.id.detail_activity_textview_title);
        TextView textViewContent = (TextView) findViewById(R.id.detail_activity_textview_content);
        ImageView imageView      = (ImageView)findViewById(R.id.detail_activity_imageview_banner);

        // Get the values from the arrays
        String title             = getResources().getStringArray(R.array.string_array_titles)[position];
        String content           = getResources().getStringArray(R.array.string_array_content)[position];
        String imgName           = getResources().getStringArray(R.array.string_array_banners)[position];

        // Get the image from the drawables folder, using the name given in the array
        int imgId                = getResources().getIdentifier(imgName, "drawable", getPackageName());
        Drawable drawable        = getDrawable(imgId);

        // Update UI
        textViewTitle.setText(title);
        textViewContent.setText(content);
        imageView.setImageDrawable(drawable);

    }
}
