package com.example.assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

//    ArrayList<integer>imgIds = new ArrayList<integer>(Arrays.asList(
//            R.drawable.img_cs, R.drawable.img_design, R.drawable.img_math,
//            R.drawable.img_se));


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }
}